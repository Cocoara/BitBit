<html>

<head>
  <link rel="icon" href="<?php echo base_url("assets/img/favicon.ico") ?>" />

  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url("assets/plugins/fontawesome-free/css/all.min.css") ?>">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Tempusdominus Bootstrap 4 -->
  <link rel="stylesheet" href="<?php echo base_url("assets/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css") ?>">
  <!-- iCheck -->
  <link rel="stylesheet" href="<?php echo base_url("assets/plugins/icheck-bootstrap/icheck-bootstrap.min.css") ?>">
  <!-- JQVMap -->
  <link rel="stylesheet" href="<?php echo base_url("assets/plugins/jqvmap/jqvmap.min.css") ?>">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url("assets/dist/css/adminlte.min.css") ?>">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="<?php echo base_url("assets/plugins/overlayScrollbars/css/OverlayScrollbars.min.css") ?>">



  <link type="text/css" rel="stylesheet" href="http://localhost/BitBit/assets/grocery_crud/themes/tablestrap/css/bootstrap.min.css">
 
 <link type="text/css" rel="stylesheet" href="http://localhost/BitBit/assets/grocery_crud/themes/tablestrap/css/bootstrap-theme.min.css">

 <link type="text/css" rel="stylesheet" href="http://localhost/BitBit/assets/grocery_crud/themes/tablestrap/css/datatables-bootstrap.min.css">

 <link type="text/css" rel="stylesheet" href="http://localhost/BitBit/assets/grocery_crud/themes/tablestrap/css/pnotify.custom.min.css">

 <link type="text/css" rel="stylesheet" href="http://localhost/BitBit/assets/grocery_crud/themes/tablestrap/css/datatables.css">

 <link type="text/css" rel="stylesheet" href="http://localhost/BitBit/assets/grocery_crud/themes/tablestrap/extras/TableTools/media/css/TableTools.css">


 <script src="http://localhost/BitBit/assets/grocery_crud/js/jquery-2.2.4.min.js"></script>

 <script src="http://localhost/BitBit/assets/grocery_crud/js/common/list.js"></script>

 <script src="http://localhost/BitBit/assets/grocery_crud/themes/tablestrap/js/jquery.dataTables.min.js"></script>

 <script src="http://localhost/BitBit/assets/grocery_crud/themes/tablestrap/js/datatables-bootstrap.min.js"></script>

 <script src="http://localhost/BitBit/assets/grocery_crud/themes/tablestrap/js/pnotify.custom.min.js"></script>

 <script src="http://localhost/BitBit/assets/grocery_crud/themes/tablestrap/js/datatables.js"></script>

 <script src="http://localhost/BitBit/assets/grocery_crud/themes/tablestrap/extras/TableTools/media/js/TableTools.min.js"></script><script src="http://localhost/BitBit/assets/grocery_crud/themes/tablestrap/extras/TableTools/media/js/ZeroClipboard.js"></script>

 


</head>

<body>


  <body class="hold-transition sidebar-mini layout-fixed">
  <div class="preloader flex-column justify-content-center align-items-center">
        <img class="animation__shake" src="<?php echo base_url("assets/img/favicon.ico") ?>" alt="BitBit cargando..." height="60" width="60">
      </div>

      <!-- Navbar -->
      <nav class="main-header navbar navbar-expand navbar-dark">
        <!-- Left navbar links -->
        <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars fa-2x mr-3"></i></a>
          </li>

          <!-- <li class="nav-item ">
            <a type="button" href="<?php echo site_url('adminUsuarios') ?>" class="btn btn-outline-secondary mr-3">Usuarios</a>
          </li>

          <li class="nav-item ">
            <a type="button" href="<?php echo site_url('user_groups') ?>" class="btn btn-outline-secondary mr-3">Grupos de usuarios</a>
          </li>

          <li class="nav-item ">
            <a type="button" href="<?php echo site_url('groups') ?>" class="btn btn-outline-secondary mr-3">Grupos</a>
          </li>

          <li class="nav-item ">
            <a type="button" href="<?php echo site_url('incidencia') ?>" class="btn btn-outline-secondary mr-3">Incidencias</a>
          </li>

          <li class="nav-item ">
            <a type="button" href="<?php echo site_url('infocontacto') ?>" class="btn btn-outline-secondary mr-3">Información del contacto</a>
          </li>

          <li class="nav-item ">
            <a type="button" href="<?php echo site_url('mail') ?>" class="btn btn-outline-secondary mr-3">Correos</a>
          </li>

          <li class="nav-item ">
            <a type="button" href="<?php echo site_url('material') ?>" class="btn btn-outline-secondary mr-3">Material</a>
          </li> -->

        </ul>
        <!-- <span class="text text-white mr-5"><img src="<?php echo base_url("assets/img/user.png") ?>" /> <?php echo $user->first_name; ?> </span> -->
        <!-- <a type="button" href="<?php echo site_url('logout') ?>" class="btn btn-danger mr-3 ">Cerrar sesión</a> -->


        </ul>
        <ul class="nav-item navbar-nav ml-auto">


          <li class="nav-item">
            <a class="nav-link" href="<?php echo site_url('logout') ?>"><img src="<?php echo base_url("assets/img/logout.png") ?>" style="width: 30px" /> Login</a>
          </li>
        </ul>
      </nav>

      <!-- Preloader -->
   