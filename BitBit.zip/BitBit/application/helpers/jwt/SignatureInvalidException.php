<?php
class SignatureInvalidException extends \UnexpectedValueException
{

}
