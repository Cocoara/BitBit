<head>
    <title>Asignación de reparaciones</title>
</head>
<style>
    @media (max-width: 576px) {
        .xs {
            color: red;
            font-weight: bold;
        }
    }

    /* Small devices (landscape phones, 576px and up) */
    @media (min-width: 576px) and (max-width:768px) {
        .sm {
            color: red;
            font-weight: bold;
        }
    }

    /* Medium devices (tablets, 768px and up) The navbar toggle appears at this breakpoint */
    @media (min-width: 768px) and (max-width:992px) {
        .md {
            color: red;
            font-weight: bold;
        }
    }

    /* Large devices (desktops, 992px and up) */
    @media (min-width: 992px) and (max-width:1200px) {
        .lg {
            color: red;
            font-weight: bold;
        }
    }

    /* Extra large devices (large desktops, 1200px and up) */
    @media (min-width: 1200px) {
        .xl {
            color: red;
            font-weight: bold;
        }
    }

    .margetop{
        margin-top: 100px;
    }
</style>


<section>

    <!-- <div class="container-fluid margetop">
        <div class="row d-flex justify-content-center">
            <?php for ($i = 0; $i < 3; $i++) { ?>
                <div class="card text-center">
                    <div class="card-header">Featured</div>
                    <div class="card-body">
                        <h5 class="card-title">Special title treatment</h5>
                        <p class="card-text">
                            With supporting text below as a natural lead-in to additional content.
                        </p>
                        <label for="cars">Asignar reparación:</label>
                        <select id="cars" name="cars">
                        <?php for($j=0;$j<1;$j++) {?>
                            <option value="volvo">Trabajador</option>
                            <?php }?>
                        </select>
                    </div>
                    <div class="card-footer text-muted">2 days ago</div>
                </div>
                &nbsp;
            <?php
            }
            ?>
        </div>
    </div> -->
</section>